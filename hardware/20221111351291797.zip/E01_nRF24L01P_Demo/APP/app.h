/**@file  	    app.h
* @brief            
* @author           hyh
* @date             2021.9.17
* @version          1.0
* @copyright        Chengdu Ebyte Electronic Technology Co.Ltd
**********************************************************************************
*/
#ifndef APP_H
#define APP_H

#include "bsp.h"
#include "MyTypeDef.h"

/*
================================================================================
----------------------------The Function Declaration----------------------------
================================================================================
*/
void APP_Process(void);
void TIM3_1ms_Interrupt_Cb(void);
void Uart_Rx_interrupt_Cb(void);
void Uart_Tx_interrupt_Cb(void);
void APP_SwitchToRx(void);
#endif
