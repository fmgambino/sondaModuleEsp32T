/**@file            main.c
* @brief            Main program entry
* @author           hyh
* @date             2021.9.17
* @version          1.0
* @copyright        Chengdu Ebyte Electronic Technology Co.Ltd
**********************************************************************************
*/
#include "bsp.h"
#include "app.h"
/*!
================================================================================
------------------------------------Functions-----------------------------------
================================================================================
*/
void main(void)
{
    System_Initial();
    APP_Process();
}